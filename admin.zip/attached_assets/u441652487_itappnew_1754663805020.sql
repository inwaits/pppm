-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 08, 2025 at 05:34 AM
-- Server version: 10.11.10-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u441652487_itappnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `asset_tag` varchar(50) NOT NULL,
  `asset_type_id` int(11) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `seller` varchar(255) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(10,2) DEFAULT NULL,
  `warranty_expiry` date DEFAULT NULL,
  `status` enum('Available','In use','In repair','Sold','Damage') DEFAULT 'Available',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_assignments`
--

CREATE TABLE `asset_assignments` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `previous_owner_id` int(11) DEFAULT NULL,
  `assigned_date` datetime DEFAULT current_timestamp(),
  `expected_return_date` date DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_requests`
--

CREATE TABLE `asset_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_type` enum('asset','repair','return') DEFAULT 'asset',
  `asset_type_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `request_reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `pickup_location` varchar(255) DEFAULT NULL,
  `pickup_notes` text DEFAULT NULL,
  `pickup_status` enum('pending','scheduled','completed') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_types`
--

CREATE TABLE `asset_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_types`
--

INSERT INTO `asset_types` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Laptop', 'Portable computers used by employees', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(2, 'Desktop', 'Office workstations', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(3, 'Monitor', 'Computer displays of various sizes', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(4, 'Mobile Device', 'Smartphones and tablets', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(5, 'Printer', 'Office printers and multifunction devices', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(6, 'Network Equipment', 'Routers, switches, and access points', '2025-04-18 10:01:18', '2025-04-18 10:01:18'),
(7, 'Software License', 'Software applications and subscriptions', '2025-04-18 10:01:18', '2025-04-18 10:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bill_type_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `vat_amount` decimal(10,2) DEFAULT 0.00,
  `reimbursed_amount` decimal(10,2) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `receipt_path` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `company` varchar(50) DEFAULT NULL,
  `cost_centre_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `user_id`, `bill_type_id`, `date`, `amount`, `vat_amount`, `reimbursed_amount`, `supplier`, `receipt_path`, `comment`, `status`, `created_at`, `company`, `cost_centre_id`) VALUES
(5, 5, 2, '2025-04-15', 120.00, 20.00, 120.00, 'lidle', '5/67fe4b9c4392b_20250415.jpg', 'test', 'Approved', '2025-04-15 12:05:48', 'PPHK', 81),
(7, 7, 4, '2025-04-15', 315.00, 20.00, 315.00, 'Lenovo', '7/67fea3b60da1c_20250415.png', 'For office', 'Approved', '2025-04-15 18:21:42', 'PPUK', 9),
(8, 7, 6, '2025-04-05', 290.00, 10.00, 290.00, 'Apple', '7/67fea3d92bd0d_20250415.png', 'For mac', 'Approved', '2025-04-15 18:22:17', 'PPHK', 66),
(9, 12, 1, '2025-04-11', 143.00, 12.65, 143.00, 'CTB', '12/67fea4329d279_20250415.png', 'For public transport', 'Approved', '2025-04-15 18:23:46', 'PPHOSPITALITY', 87),
(10, 12, 2, '2025-04-10', 126.98, 13.76, 126.98, 'Hotel Riu', '12/67fea4573c828_20250415.png', 'Hotel Riu', 'Rejected', '2025-04-15 18:24:23', 'PPUK', 13),
(11, 17, 4, '2025-03-12', 345.65, 23.97, 345.65, 'Samsung', NULL, 'Samsung', 'Approved', '2025-04-15 18:26:05', 'PPHK', 58);

-- --------------------------------------------------------

--
-- Table structure for table `bill_types`
--

CREATE TABLE `bill_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill_types`
--

INSERT INTO `bill_types` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Travel', 'Travel and transportation expenses', '2025-04-05 18:24:31'),
(2, 'Accommodation', 'Hotel and lodging expenses', '2025-04-05 18:24:31'),
(3, 'Meals', 'Food and dining expenses', '2025-04-05 18:24:31'),
(4, 'Office Supplies', 'Stationery and office materials', '2025-04-05 18:24:31'),
(5, 'Software', 'Software subscriptions and licenses', '2025-04-05 18:24:31'),
(6, 'Other', 'For other expenses', '2025-04-14 14:37:58');

-- --------------------------------------------------------

--
-- Table structure for table `cost_centres`
--

CREATE TABLE `cost_centres` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `company` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cost_centres`
--

INSERT INTO `cost_centres` (`id`, `name`, `description`, `created_at`, `company`) VALUES
(5, 'Don\'t select this', NULL, '2025-04-05 18:24:31', 'PPUK'),
(8, 'Best Western Ship, Weybridge', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(9, 'DoubleTree by Hilton Kingston-Upon-Thames', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(10, 'Hampton By Hilton Birmingham Broad Street', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(11, 'Hampton By Hilton Stansted Airport', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(12, 'Hampton By Hilton York, Toft Green', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(13, 'Hilton Garden Inn Bristol', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(14, 'Holiday Inn Basingstoke', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(15, 'Holiday Inn Gatwick Airport', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(16, 'Holiday Inn Gloucester', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(17, 'Holiday Inn Hull Marina', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(18, 'Holiday Inn Leicester', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(19, 'Holiday Inn Express London Excel', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(20, 'Holiday Inn Express Stockport', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(21, 'Hilton at the Ageas Bowl Southampton', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(22, 'Lingfield Park Marriot Hotel and Country Club', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(23, 'Pullman Liverpool', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(24, 'Warren Lodge Hotel', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(25, 'Radisson Red Gatwick', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(26, 'Crown Plaza Felbridge', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(27, 'Drayton Manor Hotel', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(28, 'DoubleTree by Hilton Swindon', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(29, 'Hilton Garden Inn Doncaster Racecourse', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(30, 'Holiday Inn Eastleigh', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(31, 'Holiday Inn High Wycombe', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(32, 'Holiday Inn Stevenage', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(33, 'Mercure York - MYF', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(34, 'Radisson Blu Cardiff', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(35, 'Radisson Red Greenwich', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(36, 'AC Hotel Manchester City Centre', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(37, 'Holiday Inn York City Centre', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(38, 'Crown Plaza Leeds', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(39, 'Holiday Inn Aylesbury', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(40, 'Holiday Inn Bexley', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(41, 'Holiday Inn Coventry', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(42, 'Holiday Inn Fareham - Solent', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(43, 'Holiday Inn Farnborough', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(44, 'Holiday Inn Hemel Hempstead', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(45, 'Holiday Inn Reading', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(46, 'Holiday Inn Southampton', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(47, 'Ibis Styles Birmingham Centre', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(48, 'Best Western Edinburgh Kings Manor Hotel', 'PPUK Hotel Location', '2025-04-05 18:46:59', 'PPUK'),
(49, 'Head Office-UK', 'PPUK Head Office', '2025-04-05 18:46:59', 'PPUK'),
(50, 'Aloft Birmingham Eastside', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(51, 'City Continental Kensington', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(52, 'C I Kings Cross', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(53, 'Double Tree by Hilton - Sheffield Park', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(54, 'HI BRENTFORD LOCK', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(55, 'Holiday Inn London - Wembley', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(56, 'HIEX Cambridge - Duxford', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(57, 'Holiday Inn Express Fleet Hotel', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(58, 'Hotel Indigo York', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(59, 'Innside by Melia Liverpool', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(60, 'Innside by Melia Manchester', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(61, 'Courtyard by Marriott Oxford South', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(62, 'Pendley Manor Hotel', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(63, 'RIU VICTORIA', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(64, 'Stanwell', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(65, 'The Samuel Ryder (Clarion), St Albans', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(66, 'Atrium Heathrow', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(67, 'H10 London Waterloo', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(68, 'Hampton By Hilton Blackpool', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(69, 'Hampton By Hilton York Piccadilly', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(70, 'Holiday Inn London - Heathrow', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(71, 'Holiday Inn Wolverhampton - Racecourse', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(72, 'Innside by Melia Newcastle', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(73, 'Novotel Leicester', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(74, 'Roland House', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(75, 'Staybridge Suites London - Heathrow', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(76, 'Hilton London Heathrow Airport Terminal 5', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(77, 'Le Mirage', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(78, 'Hub Waterloo (TFL)', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(79, 'Meliá White House', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(80, 'Meliá London Kensington', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(81, 'Head Office-HK', 'PPHK Head Office', '2025-04-05 18:46:59', 'PPHK'),
(82, 'Shendish Manor', 'PPHK Hotel Location', '2025-04-05 18:46:59', 'PPHK'),
(83, 'DTH Bristol', 'PPHOSPITALITY Hotel Location', '2025-04-05 18:46:59', 'PPHOSPITALITY'),
(84, 'City Hotel Derry', 'PPHOSPITALITY Hotel Location', '2025-04-05 18:46:59', 'PPHOSPITALITY'),
(85, 'Marketing', 'Marketing department expenses', '2025-04-05 18:47:34', 'PPHK'),
(86, 'Sales', 'Sales department expenses', '2025-04-05 18:47:34', 'PPUK'),
(87, 'Development', 'Software development expenses', '2025-04-05 18:47:34', 'PPHOSPITALITY'),
(88, 'HR', 'Human Resources expenses', '2025-04-05 18:47:34', 'PPHK'),
(89, 'Finance', 'Finance department expenses', '2025-04-05 18:47:34', 'PPUK'),
(90, 'Operations', 'Operations department expenses', '2025-04-05 18:47:34', 'PPHOSPITALITY');

-- --------------------------------------------------------

--
-- Table structure for table `handover_logs`
--

CREATE TABLE `handover_logs` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `from_user_id` int(11) DEFAULT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `handover_date` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_history`
--

CREATE TABLE `maintenance_history` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `maintenance_date` date NOT NULL,
  `maintenance_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `performed_by` varchar(100) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Completed',
  `next_maintenance_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) DEFAULT 'general',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pickup_arrangements`
--

CREATE TABLE `pickup_arrangements` (
  `id` int(11) NOT NULL,
  `request_type` enum('asset','repair','return') NOT NULL,
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `scheduled_at` datetime NOT NULL,
  `location` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('scheduled','completed','canceled') DEFAULT 'scheduled',
  `completion_date` datetime DEFAULT NULL,
  `completion_notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `repair_requests`
--

CREATE TABLE `repair_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `issue_description` text NOT NULL,
  `status` enum('pending','approved','rejected','in_progress','completed') DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `repair_cost` decimal(10,2) DEFAULT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `pickup_location` varchar(255) DEFAULT NULL,
  `pickup_notes` text DEFAULT NULL,
  `pickup_status` enum('pending','scheduled','completed') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `asset_type_id` int(11) DEFAULT NULL,
  `request_type` enum('Asset Request','Repair Request','Return Request') NOT NULL,
  `request_details` text DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Completed') NOT NULL DEFAULT 'Pending',
  `admin_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `return_requests`
--

CREATE TABLE `return_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `return_reason` text DEFAULT NULL,
  `condition_on_return` enum('Excellent','Good','Fair','Poor','Damaged') DEFAULT 'Good',
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `pickup_location` varchar(255) DEFAULT NULL,
  `pickup_notes` text DEFAULT NULL,
  `pickup_status` enum('pending','scheduled','completed') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `request_type` enum('asset','repair','return') NOT NULL,
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `scheduled_date` datetime NOT NULL,
  `location` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('scheduled','completed','postponed','cancelled') NOT NULL DEFAULT 'scheduled',
  `completion_notes` text DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'employee',
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `password`, `role`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', 'expenses@pphotel.co.uk', '$2y$10$Fu5KwXMm4QRPVRKVUsMuP.4B.cnDH57mkaAtIFM/GBtjDJUvdvk8K', 'admin', 0, '2025-04-05 18:24:31', '2025-04-18 10:03:17'),
(5, 'bliss@pphotel.co.uk', 'Bliss Prashana', 'bliss@pphotel.co.uk', '$2y$10$a8oU2Ra/SzhDfUbQXYCgvua3bapqIRklqSjpyicVhXcdoYdtOeuXu', 'employee', 0, '2025-04-07 14:06:06', '2025-04-07 14:06:06'),
(6, 'ernestina@pphotel.co.uk', 'Ernestina', 'ernestina@pphotel.co.uk', '$2y$10$qrQGytn9YixKZ1AjJWnx..JUFmDPYy2oiEROBzNZqMMTOeYfJxpHy', 'employee', 0, '2025-04-14 15:35:38', '2025-04-18 10:07:03'),
(7, 'Ewa@pphotel.co.uk', 'Ewa', 'Ewa@pphotel.co.uk', '$2y$10$zp7h3wJZZlQbwaVmWE0yL.xxhmdHbc9NJs5cSMQhhbOTFQKllBFE6', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:41:11'),
(8, 'irina@pphotel.co.uk', 'Irina', 'irina@pphotel.co.uk', '$2y$10$pLrEb01CTzPDsoUbXi2Hqu.xmZW4ygO2C9hay/6BIgQ/1XrwQjieK', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:41:24'),
(9, 'ivelina@pphotel.co.uk', 'Ivelina', 'ivelina@pphotel.co.uk', '$2y$10$8VdZB7s0hjClMsp8npMfNuD6H2JTUqwAHyidHYWzMvy8cMgnv.qr2', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:41:37'),
(10, 'Iwona@pphotel.co.uk', 'Iwona', 'Iwona@pphotel.co.uk', '$2y$10$qgyGpAPNnqjVwWomZOgU0.R.LcYYb8JaBUMueqd9FiZL3WBNszJ36', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:41:49'),
(11, 'luba@pphotel.co.uk', 'Luba', 'luba@pphotel.co.uk', '$2y$10$LuMguhWKeHhKNMNP79UduOcmZKRw/jSzfi.W1l6uKGLhwpHbkTdLm', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:42:00'),
(12, 'Madalina@pphotel.co.uk', 'Madalina', 'Madalina@pphotel.co.uk', '$2y$10$PXAfPjHz2Gr7.VeutKO85.rddwJaMG8M0Xw1mR99mkjl4ESsSn/q.', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:42:10'),
(13, 'maria@pphotel.co.uk', 'Maria', 'maria@pphotel.co.uk', '$2y$10$vyQ9s0cnTPOde9a8v.FUheuHZvH3NofUCvj1ZjdOH3KSpqUz0qKb2', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:42:21'),
(14, 'mayuri@pphotel.co.uk', 'Mayuri', 'mayuri@pphotel.co.uk', '$2y$10$JnB.BkWu6Zy3wVCCxy8iGO03qJb0rkv/8AkZYvlsv9vxRusLJmhQK', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:42:36'),
(15, 'roxana@pphotel.co.uk', 'Roxana', 'roxana@pphotel.co.uk', '$2y$10$ja4jeVzg5io26OO3508HW.3j3fmpPSios38tibFAnqm9yeXYQ2FU2', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:42:48'),
(16, 'Urszula@pphotel.co.uk', 'Urszula', 'Urszula@pphotel.co.uk', '$2y$10$3zWrv3790.gMpXmX9EhT/e9Yumgal2P/n5t9VvZIIfchFB13f0Sii', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:43:02'),
(17, 'Yash@pphotel.co.uk', 'Yash', 'Yash@pphotel.co.uk', '$2y$10$juCU0uDTe4zJ3sN0kY9/eu8.nD2l886gQiBovb0cWAtW2pyN88Y/C', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:43:15'),
(18, 'Nishantha@pphotel.co.uk', 'Nishantha', 'Nishantha@pphotel.co.uk', '$2y$10$zygLwcsWS6w89OG7VXCiZu69j5My9PhMrKi8mIS6D3wdpK.TnAokC', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:43:30'),
(19, 'Daniela@pphotel.co.uk', 'Daniela', 'Daniela@pphotel.co.uk', '$2y$10$DNgeu6JzNImk9jEkLqkz1udF8P5Alp2V2c9S.Rx2vwCk7oElwtVHe', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:43:39'),
(20, 'roshan@pphotel.co.uk', 'Roshan', 'roshan@pphotel.co.uk', '$2y$10$McNnmqz6GGS8BRyvQvvAV.gbaxyTQpsgqBnnqZcKpEy8vGbrZ9mui', 'employee', 0, '2025-04-14 15:35:38', '2025-04-14 15:43:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `asset_tag` (`asset_tag`),
  ADD KEY `idx_assets_asset_type` (`asset_type_id`),
  ADD KEY `idx_assets_status` (`status`);

--
-- Indexes for table `asset_assignments`
--
ALTER TABLE `asset_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `previous_owner_id` (`previous_owner_id`);

--
-- Indexes for table `asset_requests`
--
ALTER TABLE `asset_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_type_id` (`asset_type_id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `bill_type_id` (`bill_type_id`),
  ADD KEY `cost_centre_id` (`cost_centre_id`);

--
-- Indexes for table `bill_types`
--
ALTER TABLE `bill_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cost_centres`
--
ALTER TABLE `cost_centres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `handover_logs`
--
ALTER TABLE `handover_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `from_user_id` (`from_user_id`),
  ADD KEY `to_user_id` (`to_user_id`);

--
-- Indexes for table `maintenance_history`
--
ALTER TABLE `maintenance_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pickup_arrangements`
--
ALTER TABLE `pickup_arrangements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `repair_requests`
--
ALTER TABLE `repair_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `asset_type_id` (`asset_type_id`);

--
-- Indexes for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_assignments`
--
ALTER TABLE `asset_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_requests`
--
ALTER TABLE `asset_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_types`
--
ALTER TABLE `asset_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `bill_types`
--
ALTER TABLE `bill_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cost_centres`
--
ALTER TABLE `cost_centres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `handover_logs`
--
ALTER TABLE `handover_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `maintenance_history`
--
ALTER TABLE `maintenance_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pickup_arrangements`
--
ALTER TABLE `pickup_arrangements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `repair_requests`
--
ALTER TABLE `repair_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `return_requests`
--
ALTER TABLE `return_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `asset_assignments`
--
ALTER TABLE `asset_assignments`
  ADD CONSTRAINT `asset_assignments_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_assignments_ibfk_3` FOREIGN KEY (`previous_owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `asset_requests`
--
ALTER TABLE `asset_requests`
  ADD CONSTRAINT `asset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_requests_ibfk_2` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `asset_requests_ibfk_3` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `bills`
--
ALTER TABLE `bills`
  ADD CONSTRAINT `bills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`bill_type_id`) REFERENCES `bill_types` (`id`),
  ADD CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`cost_centre_id`) REFERENCES `cost_centres` (`id`);

--
-- Constraints for table `handover_logs`
--
ALTER TABLE `handover_logs`
  ADD CONSTRAINT `handover_logs_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `handover_logs_ibfk_2` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `handover_logs_ibfk_3` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `maintenance_history`
--
ALTER TABLE `maintenance_history`
  ADD CONSTRAINT `maintenance_history_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `pickup_arrangements`
--
ALTER TABLE `pickup_arrangements`
  ADD CONSTRAINT `pickup_arrangements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pickup_arrangements_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `repair_requests`
--
ALTER TABLE `repair_requests`
  ADD CONSTRAINT `repair_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `repair_requests_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `requests_ibfk_3` FOREIGN KEY (`asset_type_id`) REFERENCES `asset_types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `return_requests`
--
ALTER TABLE `return_requests`
  ADD CONSTRAINT `return_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `return_requests_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`);

--
-- Constraints for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD CONSTRAINT `system_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
